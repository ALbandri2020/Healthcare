﻿
Partial Class cp_Default
    Inherits System.Web.UI.Page

End Class
